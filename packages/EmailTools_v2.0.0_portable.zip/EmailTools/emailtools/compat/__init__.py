"""EmailTools unified application."""
